package com.example.midtermProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MidtermProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
